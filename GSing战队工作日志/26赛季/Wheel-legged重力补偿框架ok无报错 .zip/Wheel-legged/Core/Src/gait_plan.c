/*
 * gait_plan.c
 *
 *  Created on: Dec 29, 2025
 *      Author: FMI
 */

#include "gait_plan.h"
#include "arm_math.h"
#include "Matrix.h"

#define LEFT_SIDE 0
#define RIGHT_SIDE 1

// 机械腿尺寸参数初始化函数
void params_init(leg_size *leg_size, float thigh_length, float shin_length, 
float angle1_max, float angle1_min, float angle2_max, float angle2_min, float wheel_diameter,
float thigh_mass, float shin_mass, float lc1, float lc2, float g)
{
    leg_size->thigh_length = thigh_length;
    leg_size->shin_length = shin_length;
    leg_size->wheel_diameter = wheel_diameter;
    leg_size->thigh_motor_angle_range.min = angle1_min;
    leg_size->thigh_motor_angle_range.max = angle1_max;
    leg_size->shin_motor_angle_range.min = angle2_min;
    leg_size->shin_motor_angle_range.max = angle2_max;
    leg_size->thigh_mass = thigh_mass;
    leg_size->shin_mass = shin_mass;
    leg_size->lc1 = lc1;
    leg_size->lc2 = lc2;
    leg_size->g = g;
};

// 步态参数初始化函数
void gait_action_init(gait_action *gait_action, float radius, float duty_ratio, float cycle_time, float point_number) 
{
    gait_action->radius = radius;
    gait_action->duty_ratio = duty_ratio;
    gait_action->cycle_time = cycle_time;
    gait_action->point_number = point_number;
};

//记录轨迹点信息函数
void gait_record(gait_action *gait_action, int indx, float x, float y, float z, float vx, float vy, float vz, float ax, float ay, float az){
    // 初始化矩阵结构体
    gait_action->position[indx].vector.numRows = 3;
    gait_action->position[indx].vector.numCols = 1;
    gait_action->position[indx].vector.pData = gait_action->position[indx].data;

    gait_action->velocity[indx].vector.numRows = 3;
    gait_action->velocity[indx].vector.numCols = 1;
    gait_action->velocity[indx].vector.pData = gait_action->velocity[indx].data;

    gait_action->acceleration[indx].vector.numRows = 3;
    gait_action->acceleration[indx].vector.numCols = 1;
    gait_action->acceleration[indx].vector.pData = gait_action->acceleration[indx].data;
    // 记录数据
    gait_action->position[indx].data[0] = x;
    gait_action->position[indx].data[1] = y;
    gait_action->position[indx].data[2] = z;

    gait_action->velocity[indx].data[0] = vx;
    gait_action->velocity[indx].data[1] = vy;
    gait_action->velocity[indx].data[2] = vz;

    gait_action->acceleration[indx].data[0] = ax;
    gait_action->acceleration[indx].data[1] = ay;
    gait_action->acceleration[indx].data[2] = az;

    x = 0.0f, y = 0.0f, z = 0.0f;
    vx = 0.0f, vy = 0.0f, vz = 0.0f;
    ax = 0.0f, ay = 0.0f, az = 0.0f;
};

//计算出右前腿向前迈的轨迹点位置信息、速度信息和加速度信息,此处以时间为索引依据进行计算；摆线默认起点在对应腿坐标系下的原点
void compete_gait(gait_action *gait_action, leg_size *leg_size){
    int point_number = gait_action->point_number;   // 轨迹点个数
    float cycle_time = gait_action->cycle_time; // 周期时间
    float duty_ratio = gait_action->duty_ratio;  // 占空比
    float radius = gait_action->radius; // 摆线半径
    
    float distance = gait_action->radius * 2.0f * PI; // 每个周期前进的距离
    float support_speed = distance / (cycle_time * duty_ratio); // 支撑相直线速度
    float swing_speed = 2.0f * PI / (cycle_time * (1.0f - duty_ratio)); // 摆动相角速度
    float duty_time = cycle_time / point_number; // 每个轨迹点对应的时间间隔

    float front_time = cycle_time * duty_ratio / 2.0f; // 支撑相前半段时间,其实也是后半段的时间

    float x = 0.0f, y = 0.0f, z = 0.0f;
    float vx = 0.0f, vy = 0.0f, vz = 0.0f;
    float ax = 0.0f, ay = 0.0f, az = 0.0f;// 位置、速度、加速度变量初始都为0.0f
    for(float t = 0.0f; t < cycle_time; t += duty_time ){
        if(t < front_time){
            y = -t * support_speed;
            vy = -support_speed;

            gait_record(gait_action, (int)(t/duty_time), x, y, z, vx, vy, vz, ax, ay, az);
        }
        else if(t >= front_time && t < (cycle_time - front_time)){
            float t_use = t - front_time;
            y = radius * ((t_use * swing_speed) - sin(t_use * swing_speed)) - (gait_action->radius * PI);
            z = radius * (1.0f - cos(t_use * swing_speed));
            vy = radius * swing_speed * (1.0f - cos(t_use * swing_speed));
            vz = radius * swing_speed * sin(t_use * swing_speed);
            ay = radius * swing_speed * swing_speed * sin(t_use * swing_speed);
            az = radius * swing_speed * swing_speed * cos(t_use * swing_speed);

            gait_record(gait_action, (int)(t/duty_time), x, y, z, vx, vy, vz, ax, ay, az);
        }
        else if(t >= (cycle_time - front_time)){
             float t_use = t - (cycle_time - front_time);
            y = (distance / 2) - t_use * support_speed;
            vy = support_speed;
            
            gait_record(gait_action, (int)(t/duty_time), x, y, z, vx, vy, vz, ax, ay, az);
        }
    }

};

//运动学逆解1，计算给定位置对应的电机角度
//二次修改，2026.1.30，明确一下腿的计算角度逻辑。配合重力补偿函数的角度定义，现在每条腿都从竖直状态为初始位置去做数学计算，但肯定要考虑实际限位的问题
void inverse_kinematics_position(leg_size *leg_size, vector *position, vector *motor_angle, int state){
    //分左边腿和右边腿，为了区分电机的角度
    if(state == LEFT_SIDE){
//        float x = position->data[0];//留给3自由度时的一个起点
        float y = position->data[1];
        float z = position->data[2];

        float L1 = leg_size->thigh_length;
        float L2 = leg_size->shin_length;

/*/由于我不是什么天才，所以在这里严格规定：
theta0指的是从身体基准坐标系变换到腿基准坐标系的角度
（改前）theta1指的是大腿电机的角度（从腿基准坐标系变换到大腿电机坐标系的度数）
（改版）theta1指的是大腿电机的角度（初始位置是当腿竖直时，theta1=0）
（改前）theta2一定指的是小腿电机的角度（从大腿电机坐标系变换到小腿电机坐标系的度数）就是膝关节内侧的度数
（改版）theta2一定指的是小腿电机的角度（初始位置是当与大腿呈一条直线时，theta2=0），也就是小腿与大腿延长线的夹角
而且默认只进行两次的矩阵变换，这样一来就可以得出死公式了
/*/
        motor_angle->data[0] = 0.0f;
        float theta2 = acos((L1*L1 + L2*L2 - (y*y + z*z)) / (2.0f * L1 * L2));
        motor_angle->data[2] = theta2 - PI;
 

        motor_angle->data[1] = atan2(z, y) + atan2(L2 * sin(PI - theta2), L1 + L2 * cos(theta2 - PI)) + PI; //这个角度左边腿是加右边腿减，因为电机是顺时针为弧度减小。现在是左边腿
    }
    else if (state == RIGHT_SIDE){
//        float x = position->data[0];//留给3自由度时的一个起点
        float y = position->data[1];
        float z = position->data[2];

        float L1 = leg_size->thigh_length;
        float L2 = leg_size->shin_length;

        motor_angle->data[0] = 0.0f;

        float theta2 = acos((L1*L1 + L2*L2 - (y*y + z*z)) / (2.0f * L1 * L2));
        motor_angle->data[2] = PI - theta2;

        motor_angle->data[1] = atan2(z, y) + PI - atan2(L2 * sin(PI - theta2), L1 - L2 * cos(PI - theta2)); //右边腿大腿电机角度是减
    }
};

//运动学逆解二，给定足端速度信息，计算对应的电机角速度信息
void inverse_kinematics_velocity(leg_size *leg_size, vector *velocity, vector *motor_angle, vector *motor_angular_velocity){

    //实时计算的雅可比矩阵
    float J[4];
    float theta1 = motor_angle->data[1];
    float theta2 = motor_angle->data[2];
    float vy = velocity->data[1];
    float vz = velocity->data[2];

    update_Jacobian_2x2(leg_size, theta1, theta2, J);
    // 1. 计算行列式 det(J) = ad - bc
    float det = J[0] * J[3] - J[1] * J[2];
    // 3. 使用逆矩阵公式计算：
    // dq1 = (1/det) * ( d * vy + (-b) * vz)
    // dq2 = (1/det) * (-c * vy +   a  * vz)
    float inv_det = 1.0f / det;
    motor_angular_velocity->data[1] = inv_det * ( J[3] * vy - J[1] * vz);
    motor_angular_velocity->data[2] = inv_det * (-J[2] * vy + J[0] * vz);

};

