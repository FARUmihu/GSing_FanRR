/*
 * F_Pos_Hybrid_control.c
 *
 *  Created on: Jan 2, 2026
 *      Author: FMI
 */
 
#include "F_Pos_Hybrid_control.h"
#include "usart.h"
#include "main.h"
#include "Go-motor.h"

MotorInstance GO;

//电机是单圈绝对值输出，那么我想要知道在安装时带来的角度影响，可以直接将这些误差值输入到一个专门的结构体中
void motor_angle_init(start_angle *start_angle, 
                    int32_t angle0, int32_t angle1, int32_t angle2, 
                    int32_t angle3, int32_t angle4, int32_t angle5, 
                    int32_t angle6, int32_t angle7, int32_t angle8, 
                    int32_t angle9, int32_t angle10, int32_t angle11){
    start_angle->angle[0] = angle0;
    start_angle->angle[1] = angle1;
    start_angle->angle[2] = angle2;
    start_angle->angle[3] = angle3;
    start_angle->angle[4] = angle4;
    start_angle->angle[5] = angle5;
    start_angle->angle[6] = angle6;
    start_angle->angle[7] = angle7;
    start_angle->angle[8] = angle8;
    start_angle->angle[9] = angle9;
    start_angle->angle[10] = angle10;
    start_angle->angle[11] = angle11;
}

void gravity_compensation(leg_size *leg_size, vector *motor_angle, vector *tau){
    // 为了提高计算效率，提前计算三角函数
    
    float s1 = sinf(motor_angle->data[1]);
    float s12 = sinf(motor_angle->data[1] + motor_angle->data[2]);

    float m1 = leg_size->thigh_mass;
    float m2 = leg_size->shin_mass;
    float L1 = leg_size->thigh_length;
    float g = leg_size->g;
    /*
     * 推导原理：
     * 1. 大腿受到的重力矩 = 大腿自重力矩 + 小腿重量传导回来的力矩
     * 2. 小腿受到的重力矩 = 小腿自重力矩
     * 根据势能对角度求偏导得出：
     */
    tau->data[1] = -m1 * g * L1 * s1 - m2 * g * L1 * s12;
    tau->data[2] = -m2 * g * L1 * s12;
}
