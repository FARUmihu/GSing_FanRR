#include "pid.h"

// 初始化PID控制器
void PID_Init(PID_Controller* pid, float Kp, float Ki, float Kd,
              float output_max, float output_min,
              float integral_max, float integral_min) {
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;

    pid->integral = 0.0f;
    pid->prev_error = 0.0f;
    pid->prev_measure = 0.0f;
    pid->output = 0.0f;

    pid->output_max = output_max;
    pid->output_min = output_min;

    pid->integral_max = integral_max;
    pid->integral_min = integral_min;

    pid->last_time = 0;
}

// 重置PID控制器
void PID_Reset(PID_Controller* pid) {
    pid->integral = 0.0f;
    pid->prev_error = 0.0f;
    pid->prev_measure = 0.0f;
    pid->output = 0.0f;
    pid->last_time = 0;
}

// 更新PID计算(位置式PID)
float PID_Update(PID_Controller* pid, float setpoint, float measurement, uint32_t current_time) {
    // 计算时间差(毫秒)
    float dt = (pid->last_time == 0) ? 0.01f : (current_time - pid->last_time) / 1000.0f;
    pid->last_time = current_time;

    // 确保dt在合理范围内(避免过大或过小)
    if(dt <= 0) dt = 0.01f;
    if(dt > 1.0f) dt = 0.1f;

    // 计算误差
    float error = setpoint - measurement;

    // 比例项
    float proportional = pid->Kp * error;

    // 积分项(带抗饱和)
    pid->integral += error * dt;

    // 积分限幅
    if(pid->integral > pid->integral_max) pid->integral = pid->integral_max;
    if(pid->integral < pid->integral_min) pid->integral = pid->integral_min;

    float integral = pid->Ki * pid->integral;

    // 微分项(使用测量值变化率而不是误差变化率，减少设定值突变的影响)
    float derivative = pid->Kd * (measurement - pid->prev_measure) / dt;
//    if(derivative > 50) derivative = 50;
//    if(derivative < -50) derivative = -50;//自行添加的，原因是由于反馈的数据的量级原因，kd带来的影响超级大，导致非常抖动，遂尝试进行上下限限制try try
    pid->prev_measure = measurement;

    // 计算输出
    pid->output = proportional + integral - derivative;

    // 输出限幅
    if(pid->output > pid->output_max) pid->output = pid->output_max;
    if(pid->output < pid->output_min) pid->output = pid->output_min;

    return pid->output;
}

// 更新PID计算(增量式PID)
float PID_Update_Incremental(PID_Controller* pid, float setpoint, float measurement, uint32_t current_time) {
    // 计算时间差(毫秒)
    float dt = (pid->last_time == 0) ? 0.01f : (current_time - pid->last_time) / 1000.0f;
    pid->last_time = current_time;

    // 确保dt在合理范围内
    if(dt <= 0) dt = 0.01f;
    if(dt > 1.0f) dt = 0.1f;

    // 计算误差
    float error = setpoint - measurement;

    // 计算增量
    float delta_output = pid->Kp * (error - pid->prev_error) +
                         pid->Ki * error * dt +
                         pid->Kd * (error - 2 * pid->prev_error + pid->prev_measure) / dt;

    // 更新状态
    pid->prev_measure = pid->prev_error;
    pid->prev_error = error;

    // 计算输出
    pid->output += delta_output;

    // 输出限幅
    if(pid->output > pid->output_max) pid->output = pid->output_max;
    if(pid->output < pid->output_min) pid->output = pid->output_min;

    return pid->output;
}

