/*
 * Matrix.c
 *
 *  Created on: Dec 24, 2025
 *      Author: FMI
 */

#include "Matrix.h"
#include "math.h"
#include "arm_math.h"
#include "gait_plan.h"

#define ROWS 4     //行
#define COLS 4     //列
//一个关于坐标系的共识，所有相关矩阵的描述，全部采用3轴坐标系（左手螺旋定则,即：拇指指向轴正向，四指弯曲方向为正角），机械狗的头朝向为y轴，垂直于机械狗身体平面为z轴，x轴比划比划左手三指就知道；
//所以，在代码中腿的关节转动，以及轮毂的转动轴都是平行于x轴的，而为了简便计算和理解，人为规定腿的关节用y、z轴来描述

// 辅助函数：将矩阵初始化为单位阵
void identity(arm_matrix_instance_f32 *T) {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            T->pData[i * COLS + j] = (i == j) ? 1.0 : 0.0;
        }
    }
}

// 将矩阵T先绕原 X 轴(theta1)，再绕原 Y 轴(theta2)，最后原 Z 轴(theta3)
// 所有角度基于初始原坐标系（extrinsic X-Y-Z）
// 然后平移到原坐标 (x, y, z)
void compute_transform_XYZ_fixed(
	float theta1,   // 绕 X 轴（yz平面）
	float theta2,   // 绕 Y 轴（xz平面）
	float theta3,   // 绕 Z 轴（xy平面）
	float x,
	float y,
	float z,
	arm_matrix_instance_f32 *T
) {
	T->numRows = ROWS;
	T->numCols = COLS;
	float c1 = cos(theta1), s1 = sin(theta1);
	float c2 = cos(theta2), s2 = sin(theta2);
	float c3 = cos(theta3), s3 = sin(theta3);

    // R = Rz(theta3) * Ry(theta2) * Rx(theta1)
    T->pData[0] = c3 * c2;
    T->pData[1] = c3 * s2 * s1 - s3 * c1;
    T->pData[2] = c3 * s2 * c1 + s3 * s1;
    T->pData[3] = x;

    T->pData[4] = s3 * c2;
    T->pData[5] = s3 * s2 * s1 + c3 * c1;
    T->pData[6] = s3 * s2 * c1 - c3 * s1;
    T->pData[7] = y;

    T->pData[8] = -s2;
    T->pData[9] = c2 * s1;
    T->pData[10] = c2 * c1;
    T->pData[11] = z;

    // 齐次坐标最后一行
    T->pData[12] = 0.0;
    T->pData[13] = 0.0;
    T->pData[14] = 0.0;
    T->pData[15] = 1.0;
}

// 专用 2x2 雅可比更新函数
// input: 关节角 theta1(大腿), theta2(小腿)
// output: 2x2 矩阵数组
void update_Jacobian_2x2(leg_size *leg, float t1, float t2, float J[4]) {
    float L1 = leg->thigh_length;
    float L2 = leg->shin_length;

    float s1 = sinf(t1);
    float c1 = cosf(t1);
    float s12 = sinf(t1 + t2);
    float c12 = cosf(t1 + t2);

    // Row 0: dY/dt1, dY/dt2
    J[0] = L1 * c1 + L2 * c12;  // J11
    J[1] = L2 * c12;           // J12

    // Row 1: dZ/dt1, dZ/dt2
    J[2] = L1 * s1 + L2 * s12;  // J21
    J[3] = L2 * s12;           // J22
}
