/*
 * gait_plan.h
 *
 *  Created on: Dec 29, 2025
 *      Author: FMI
 */

#ifndef INC_GAIT_PLAN_H_
#define INC_GAIT_PLAN_H_


#include "arm_math.h"

#define MAX_GAIT_POINT_NUMBER 100

// 定义一个表示范围的结构体
typedef struct
{
    float min;
    float max;
} range;

// 轨迹点的向量形式存储
typedef struct
{
    arm_matrix_instance_f32 vector;      // float thigh_length;向量 [ ,  ,  ]^T
    float data[3];            // 数据存储
} vector;

// 机械腿尺寸参数。引用了range结构体来表示电机的限制角度范围
typedef struct
{
	float thigh_length; // 大腿全长 (m)
	float shin_length;  // 小腿全长 (m)
	float wheel_diameter; // 轮子直径 (m)
	range thigh_motor_angle_range; // 大腿电机角度范围
	range shin_motor_angle_range;  // 小腿电机角度范围

    float thigh_mass;    // 大腿质量 (kg)
    float shin_mass;     // 小腿质量 (kg)  
    float lc1;   // 大腿质心距离 (髋关节到大腿质心的距离, m)
    float lc2;   // 小腿质心距离 (膝关节到小腿质心的距离, m)
    float g;     // 重力加速度 (9.81)
}leg_size;

// 步态参数结构体
typedef struct 
{
	float radius;		  // 摆线轨迹半径
	float duty_ratio;	  // 占空比 = 支撑相 / 总周期时间
	float cycle_time;	 // 周期时间
	float point_number;	 // 轨迹点数量
	vector position[MAX_GAIT_POINT_NUMBER];  // 位置
	vector velocity[MAX_GAIT_POINT_NUMBER];  // 速度
	vector acceleration[MAX_GAIT_POINT_NUMBER];  // 加速度

} gait_action;

void params_init(leg_size *leg_size, float thigh_length, float shin_length, 
float angle1_max, float angle1_min, float angle2_max, float angle2_min, float wheel_diameter,
float thigh_mass, float shin_mass, float lc1, float lc2, float g);

void gait_action_init(gait_action *gait_action, float radius, float duty_ratio, float cycle_time, float point_number);
void compete_gait(gait_action *gait_action, leg_size *leg_size);
void gait_record(gait_action *gait_action, int indx, float x, float y, float z, float vx, float vy, float vz, float ax, float ay, float az);
void inverse_kinematics_position(leg_size *leg_size, vector *position, vector *motor_angle, int state);
void inverse_kinematics_velocity(leg_size *leg_size, vector *velocity, vector *motor_angle, vector *motor_angular_velocity);

#endif /* INC_GAIT_PLAN_H_ */
