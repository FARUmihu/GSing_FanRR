/*
 * F_Pos_Hybrid_control.h
 *
 *  Created on: Jan 2, 2026
 *      Author: FMI
 */

#ifndef INC_F_POS_HYBRID_CONTROL_H_
#define INC_F_POS_HYBRID_CONTROL_H_

#include "gait_plan.h"
#include "Matrix.h"
#include "GO-motor.h"

#define MAX_MOTOR_BACK_POINT 1000
//结构体大军


//记录各个电机的初始角度
typedef struct
{
    int32_t angle[MOTOR_NUM];
} start_angle;

//描述一个空间变换的齐次变换矩阵
typedef struct
{
    int No;
    arm_matrix_instance_f32 T; //齐次变换矩阵     4*4
} HTM;

//第一阶段，放在架子上标定动力学模型参数。持续存储电机回传的数据
typedef struct
{
    int id;
    int32_t pos[MAX_MOTOR_BACK_POINT];
    //关于速度就综合角度的一次微分结果以及直接采样的结果吧，比例参数是k1
    int16_t velocity[MAX_MOTOR_BACK_POINT];
    //关于加速度就综合用角度的二次微分结果和速度的一次微分结果吧，比例参数是k2
    int16_t acceleration[MAX_MOTOR_BACK_POINT];
    float k1;//给速度比例参数
    float k2;//给加速度比例参数

    //一些相关参数，比如数据索引，滤波参数（因为对直接采样值——pos，velocity大概会有噪声）
    int index;//索引
    int filter_parameter;//滤波参数
    
} Motor_back;

//将电机初始化的角度保存在start_angle结构体中
void motor_angle_init(start_angle *start_angle, 
                    int32_t angle0, int32_t angle1, int32_t angle2, 
                    int32_t angle3, int32_t angle4, int32_t angle5, 
                    int32_t angle6, int32_t angle7, int32_t angle8, 
                    int32_t angle9, int32_t angle10, int32_t angle11
);

//重力补偿计算,对腿自身重力
void gravity_compensation(leg_size *leg_size, vector *motor_angle, vector *tau);


#endif /* INC_F_POS_HYBRID_CONTROL_H_ */
