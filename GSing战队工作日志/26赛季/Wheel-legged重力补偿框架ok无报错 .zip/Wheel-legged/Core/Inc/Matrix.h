/*
 * Matrix.h
 *
 *  Created on: Dec 24, 2025
 *      Author: FMI
 */

#ifndef INC_MATRIX_H_
#define INC_MATRIX_H_

#include "math.h"
#include "arm_math.h"
#include "gait_plan.h"

//用于便捷操作矩阵元素的宏定义，仅限于4*4的矩阵
#define HTM_GET(T, row, col) ((T)->pData[(row)*4 + (col)])
#define HTM_SET(T, row, col, val) ((T)->pData[(row)*4 + (col)] = (val))

#define HTM_X(T) HTM_GET(T, 0, 3)                // 提取X平移
#define HTM_Y(T) HTM_GET(T, 1, 3)                // 提取Y平移
#define HTM_Z(T) HTM_GET(T, 2, 3)                // 提取Z平移



void compute_transform_XYZ_fixed(
	float theta1,   // 绕 X 轴（yz平面）
	float theta2,   // 绕 Y 轴（xz平面）
	float theta3,   // 绕 Z 轴（xy平面）
	float x,
	float y,
	float z,
	arm_matrix_instance_f32 *T
);

void update_Jacobian_2x2(leg_size *leg, float t1, float t2, float J[4]);

#endif /* INC_MATRIX_H_ */
