#ifndef __PID_H
#define __PID_H

#include "stm32h7xx_hal.h"
#include <stdint.h>
#include <math.h>

// PID控制器结构体
typedef struct {
    float Kp;           // 比例增益
    float Ki;           // 积分增益
    float Kd;           // 微分增益

    float integral;     // 积分项累计值
    float prev_error;   // 上一次误差值
    float prev_measure; // 上一次测量值

    float output;       // 当前输出值
    float output_max;   // 输出上限
    float output_min;   // 输出下限

    float integral_max; // 积分项上限(抗积分饱和)
    float integral_min; // 积分项下限

    uint32_t last_time; // 上一次更新时间
} PID_Controller;

// 初始化PID控制器
void PID_Init(PID_Controller* pid, float Kp, float Ki, float Kd,
              float output_max, float output_min,
              float integral_max, float integral_min);

// 重置PID控制器
void PID_Reset(PID_Controller* pid);

// 更新PID计算(位置式PID)
float PID_Update(PID_Controller* pid, float setpoint, float measurement, uint32_t current_time);

// 更新PID计算(增量式PID)
float PID_Update_Incremental(PID_Controller* pid, float setpoint, float measurement, uint32_t current_time);

#endif


