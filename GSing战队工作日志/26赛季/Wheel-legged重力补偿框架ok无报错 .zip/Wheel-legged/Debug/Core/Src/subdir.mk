################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/F_Pos_Hybrid_control.c \
../Core/Src/GO-motor.c \
../Core/Src/M3508.c \
../Core/Src/Matrix.c \
../Core/Src/dma.c \
../Core/Src/fdcan.c \
../Core/Src/gait_plan.c \
../Core/Src/gpio.c \
../Core/Src/leg_dynamics.c \
../Core/Src/main.c \
../Core/Src/pid.c \
../Core/Src/stm32h7xx_hal_msp.c \
../Core/Src/stm32h7xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32h7xx.c \
../Core/Src/usart.c 

OBJS += \
./Core/Src/F_Pos_Hybrid_control.o \
./Core/Src/GO-motor.o \
./Core/Src/M3508.o \
./Core/Src/Matrix.o \
./Core/Src/dma.o \
./Core/Src/fdcan.o \
./Core/Src/gait_plan.o \
./Core/Src/gpio.o \
./Core/Src/leg_dynamics.o \
./Core/Src/main.o \
./Core/Src/pid.o \
./Core/Src/stm32h7xx_hal_msp.o \
./Core/Src/stm32h7xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32h7xx.o \
./Core/Src/usart.o 

C_DEPS += \
./Core/Src/F_Pos_Hybrid_control.d \
./Core/Src/GO-motor.d \
./Core/Src/M3508.d \
./Core/Src/Matrix.d \
./Core/Src/dma.d \
./Core/Src/fdcan.d \
./Core/Src/gait_plan.d \
./Core/Src/gpio.d \
./Core/Src/leg_dynamics.d \
./Core/Src/main.d \
./Core/Src/pid.d \
./Core/Src/stm32h7xx_hal_msp.d \
./Core/Src/stm32h7xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32h7xx.d \
./Core/Src/usart.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m7 -std=gnu11 -g3 -DDEBUG -DUSE_PWR_LDO_SUPPLY -DUSE_HAL_DRIVER -DSTM32H723xx -c -I../Core/Inc -I../Drivers/STM32H7xx_HAL_Driver/Inc -I../Drivers/STM32H7xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32H7xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/ST/ARM/DSP/Inc -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/F_Pos_Hybrid_control.cyclo ./Core/Src/F_Pos_Hybrid_control.d ./Core/Src/F_Pos_Hybrid_control.o ./Core/Src/F_Pos_Hybrid_control.su ./Core/Src/GO-motor.cyclo ./Core/Src/GO-motor.d ./Core/Src/GO-motor.o ./Core/Src/GO-motor.su ./Core/Src/M3508.cyclo ./Core/Src/M3508.d ./Core/Src/M3508.o ./Core/Src/M3508.su ./Core/Src/Matrix.cyclo ./Core/Src/Matrix.d ./Core/Src/Matrix.o ./Core/Src/Matrix.su ./Core/Src/dma.cyclo ./Core/Src/dma.d ./Core/Src/dma.o ./Core/Src/dma.su ./Core/Src/fdcan.cyclo ./Core/Src/fdcan.d ./Core/Src/fdcan.o ./Core/Src/fdcan.su ./Core/Src/gait_plan.cyclo ./Core/Src/gait_plan.d ./Core/Src/gait_plan.o ./Core/Src/gait_plan.su ./Core/Src/gpio.cyclo ./Core/Src/gpio.d ./Core/Src/gpio.o ./Core/Src/gpio.su ./Core/Src/leg_dynamics.cyclo ./Core/Src/leg_dynamics.d ./Core/Src/leg_dynamics.o ./Core/Src/leg_dynamics.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/pid.cyclo ./Core/Src/pid.d ./Core/Src/pid.o ./Core/Src/pid.su ./Core/Src/stm32h7xx_hal_msp.cyclo ./Core/Src/stm32h7xx_hal_msp.d ./Core/Src/stm32h7xx_hal_msp.o ./Core/Src/stm32h7xx_hal_msp.su ./Core/Src/stm32h7xx_it.cyclo ./Core/Src/stm32h7xx_it.d ./Core/Src/stm32h7xx_it.o ./Core/Src/stm32h7xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32h7xx.cyclo ./Core/Src/system_stm32h7xx.d ./Core/Src/system_stm32h7xx.o ./Core/Src/system_stm32h7xx.su ./Core/Src/usart.cyclo ./Core/Src/usart.d ./Core/Src/usart.o ./Core/Src/usart.su

.PHONY: clean-Core-2f-Src

