Core/Src/Matrix.o: ../Core/Src/Matrix.c ../Core/Inc/Matrix.h \
 ../Middlewares/ST/ARM/DSP/Inc/arm_math.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h ../Core/Inc/gait_plan.h \
 ../Core/Inc/gait_plan.h
../Core/Inc/Matrix.h:
../Middlewares/ST/ARM/DSP/Inc/arm_math.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Core/Inc/gait_plan.h:
../Core/Inc/gait_plan.h:
