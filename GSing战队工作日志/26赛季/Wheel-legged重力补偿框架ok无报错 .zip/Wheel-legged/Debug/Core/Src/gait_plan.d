Core/Src/gait_plan.o: ../Core/Src/gait_plan.c ../Core/Inc/gait_plan.h \
 ../Middlewares/ST/ARM/DSP/Inc/arm_math.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h ../Core/Inc/Matrix.h \
 ../Core/Inc/gait_plan.h
../Core/Inc/gait_plan.h:
../Middlewares/ST/ARM/DSP/Inc/arm_math.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Core/Inc/Matrix.h:
../Core/Inc/gait_plan.h:
