#ifndef __MAIN_H__
#define __MAIN_H__

/*HEAD*/
#include "stm32f4xx.h"

/*BSP*/
#include "bsp_clkconfig.h"
#include "bsp_debug_usart.h"
#include "bsp_usart_dma.h"
#include "bsp_general_tim.h"
#include "bsp_key.h" 

/*APP*/
#include "motor_control.h" 
#include "pid.h"
#include "GO_M8010_6.h"
//#include "crc_ccitt.h"

#include <stdint.h>
#include "ris_protocol.h"

#endif


