#ifndef MOTOR_CONTROL_H
#define	MOTOR_CONTROL_H

#include "stm32f4xx.h"

int Motor_pid_count(void);
int Motor_Mode_Init(void);
int Motor_data_update(void);
int Motor_date_send(void);
void Motor_Key (void);
void PID_Init(void);
void Pos_speed_control(float feedback_pos,float set_pos,float pos_speed);
#endif 

