#ifndef __USART_DMA_H
#define	__USART_DMA_H

#include "stm32f4xx.h"
#include <stdio.h>

//DMA
#define DEBUG_USART_DR_BASE               (USART6_BASE+0x04)		
#define SENDBUFF_SIZE                     16	//���͵�������
#define DEBUG_USART_DMA_CLK               RCC_AHB1Periph_DMA2
#define DEBUG_USART_DMA_CHANNEL           DMA_Channel_5
#define DEBUG_USART_DMA_STREAM            DMA2_Stream1


void USART6_DMA_Config(void);


#endif /* __USART1_H */
